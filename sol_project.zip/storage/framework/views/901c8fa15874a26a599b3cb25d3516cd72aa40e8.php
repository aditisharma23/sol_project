<?php $__env->startSection('content'); ?>
    <!-- <router-view name="customerIndex"></router-view> -->
     <router-view name="customerIndex"></router-view>
     <router-view></router-view>

    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$('.nav-link').removeClass('active');
	$('.home').addClass('active');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>