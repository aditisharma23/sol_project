 <template>
 <div class="card-body">
   <div class="info-section">
      <div class="border-1">
         <div class="pull-right dropdown">
            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-ellipsis-v pull-right"></i>
            </button>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="ServiceName">
               <a class="dropdown-item" href="#">View</a>
               <a class="dropdown-item" href="#">Add Notes</a>
               <a class="dropdown-item" href="#">Feedback</a>
            </div>
         </div>
         <p>1655 Finfar Crt Unit 2B, Mississauga</p>
         <p class="small color"><span class="yellow"><i class="fa fa-clock"></i></span> April 8, 2019, 9am-12pm</p>
      </div>
   </div>
</div>
</template>