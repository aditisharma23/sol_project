<template>
<div>
	 <div class="card-body">
		   <div class="info-section">
		      <div class="border-1">
		         <div class="pull-right dropdown">
		            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		            <i class="fa fa-ellipsis-v pull-right"></i>
		            </button>
		            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="ServiceName">
		               <a class="dropdown-item" href="#">View</a>
		               <a class="dropdown-item" href="#">Edit</a>
		               <a class="dropdown-item" href="#">Feedback</a>
		            </div>
		         </div>
		         <p>1655 Finfar Crt Unit 2B, Mississauga <span class="padder">Service Type: <strong>Cart - 64 Gallon</strong> </span> <span class="padder">Waste Type: <strong>Recycling</strong></span></p>
		         <p><span class="grey-light small border-right">ID # 549543</span> <span class="border-right color small">Every Other Week</span>  <span class="border-right color small">Next Pickup:<strong> May 29, 2019</strong></span><span class="border-right color small">Bin Pickup:<strong> N</strong></span> <i class="fas fa-exclamation-triangle yellow"></i> <label class="ml-1 btn btn-sm btn-primary">Completed</label></p>
		      </div>
		   </div>
		</div>
		<div class="card-body">
		   <div class="info-section">
		      <div class="border-1">
		         <div class="pull-right dropdown">
		            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		            <i class="fa fa-ellipsis-v pull-right"></i>
		            </button>
		            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="ServiceName">
		               <a class="dropdown-item" href="#">View</a>
		               <a class="dropdown-item" href="#">Edit</a>
		               <a class="dropdown-item" href="#">Feedback</a>
		            </div>
		         </div>
		         <p>1655 Finfar Cfrt Unit 2B, Mississauga <span class="padder">Service Type: <strong>Cart - 64 Gallon</strong> </span> <span class="padder">Waste Type: <strong>Recycling</strong></span></p>
		         <p><span class="grey-light small border-right">ID # 549543</span> <span class="border-right color small">Weekly</span>  <span class="border-right color small">Next Pickup:<strong> May 29, 2019</strong></span> <span class="border-right color small">Bin Pickup:<strong> Y</strong></span> <i class="fas fa-exclamation-triangle yellow"></i>  <label class="ml-1 btn btn-sm btn-secondary">Scheduled</label></p>
		      </div>
		   </div>
		</div>
		<div class="card-body">
		   <div class="info-section">
		      <div class="border-1">
		         <div class="pull-right dropdown">
		            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		            <i class="fa fa-ellipsis-v pull-right"></i>
		            </button>
		            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="ServiceName">
		               <a class="dropdown-item" href="#">View</a>
		               <a class="dropdown-item" href="#">Edit</a>
		               <a class="dropdown-item" href="#">Feedback</a>
		            </div>
		         </div>
		         <p>1655 Finfar Crt Unit 2B, Mississauga <span class="padder">Service Type: <strong>Cart - 64 Gallon</strong> </span> <span class="padder">Waste Type: <strong>Recycling</strong></span></p>
		         <p><span class="grey-light small border-right">ID # 549543</span> <span class="border-right color small">Monthly</span>  <span class="border-right color small">Next Pickup:<strong> May 29, 2019</strong></span><span class="border-right color small">Bin Dropoff:<strong> Y</strong></span> <label class="ml-1 btn btn-sm btn-danger">Dropoff Scheduled</label></p>
		      </div>
		   </div>
		</div>
		<div class="card-body">
		   <div class="info-section">
		      <div class="border-1">
		         <div class="pull-right dropdown">
		            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		            <i class="fa fa-ellipsis-v pull-right"></i>
		            </button>
		            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="ServiceName">
		               <a class="dropdown-item" href="#">View</a>
		               <a class="dropdown-item" href="#">Edit</a>
		               <a class="dropdown-item" href="#">Feedback</a>
		            </div>
		         </div>
		         <p>1655 Finfar Crt Unit 2B, Mississauga <span class="padder">Service Type: <strong>Cart - 64 Gallon</strong> </span> <span class="padder">Waste Type: <strong>Recycling</strong></span></p>
		         <p><span class="grey-light small border-right">ID # 549543</span> <span class="border-right color small">Every Other Week</span>  <span class="border-right color small">Next Pickup:<strong> May 29, 2019</strong></span><span class="border-right color small">Bin Dropoff:<strong> N</strong></span> <label class="ml-1 btn btn-sm btn-success">Delivered</label></p>
		      </div>
		   </div>
		</div>
</div>
</template>