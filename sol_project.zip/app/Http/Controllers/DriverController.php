<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DriverController extends Controller
{
   public function index()
   {    	
        return view('driver.index');
    }
    public function haulersignup(){
    	return view('driver.haulersignup');
    }

}
